function result=scan_load_rates(rates_MW_min, caseFactory, model)
% Scan ALL supplied rates; do not assume feasibility is monotonic.
% caseFactory(rate,model) must return [SimulationInput, meta].
% meta.Nref: timeseries of the chosen commanded power trajectory;
% meta.trackingTolerance_MW: verified tracking tolerance.
% The factory supplies UB/UW/UT and spray inputs for the ACTUAL control policy.
% No controller, plant limit, or ramp policy is invented by this function.
if nargin<3, model='lu_xin_rui_with_sh_spray'; end
assert(isa(caseFactory,'function_handle'),'A defined control policy is required.');
assert(all(isfinite(rates_MW_min)) && all(rates_MW_min>0));
folder=fileparts(mfilename('fullpath'));addpath(folder);
load_system(fullfile(folder,[model '.slx']));boiler_init_model(model);
mw=get_param(model,'ModelWorkspace');shp=mw.getVariable('shp');
assert(shp.calibrated && shp.units_confirmed, ...
    'Plant calibration and confirmed units are mandatory for load-rate estimation.');
rows=zeros(numel(rates_MW_min),6);
for j=1:numel(rates_MW_min)
    [si,meta]=caseFactory(rates_MW_min(j),model);
    assert(isa(si,'Simulink.SimulationInput') && strcmp(si.ModelName,model));
    assert(isa(meta.Nref,'timeseries') && isscalar(meta.trackingTolerance_MW) && ...
        isfinite(meta.trackingTolerance_MW) && meta.trackingTolerance_MW>0);
    rt=meta.Nref.Time(:);rv=meta.Nref.Data(:);
    assert(numel(rt)==numel(rv) && numel(rt)>=3 && all(diff(rt)>0) && all(isfinite(rv)));
    slope=60*abs(diff(rv)./diff(rt));active=slope>1e-8;
    assert(any(active) && all(abs(slope(active)-rates_MW_min(j)) ...
        <=max(1e-6,0.001*rates_MW_min(j))), ...
        'Nref must contain the declared linear ramp rate, plus optional holds.');
    % Ensure the factory does not silently restore uncalibrated parameters.
    si=si.setVariable('shp',shp,'Workspace',model);
    si=si.setModelParameter('StopTime',num2str(rt(end),17));
    out=sim(si);y=out.yout;
    n=y.getElement('Ne1').Values;
    assert(meta.Nref.Time(1)<=n.Time(1) && meta.Nref.Time(end)>=n.Time(end), ...
        'Nref must cover the entire simulation; do not extrapolate a reference.');
    ref=interp1(meta.Nref.Time,meta.Nref.Data,n.Time,'linear');
    err=max(abs(n.Data-ref));
    up=y.getElement('Margin_Tmax_C').Values;
    lo=y.getElement('Margin_Tmin_C').Values;
    sh=y.getElement('Margin_SH_C').Values;
    domain=y.getElement('PropertyDomainOK').Values;
    defined=y.getElement('SHcriterionOK').Values;
    safe=all(domain.Data) && all(defined.Data) && all(up.Data>=0) && ...
        all(lo.Data>=0) && all(sh.Data>=0);
    feasible=safe && isfinite(err) && err<=meta.trackingTolerance_MW;
    rows(j,:)=[rates_MW_min(j),err,min(up.Data),min(lo.Data),min(sh.Data),feasible];
end
result.table=array2table(rows,'VariableNames',{'CommandRate_MW_min', ...
    'MaxTrackingError_MW','MinUpperMargin_C','MinLowerMargin_C','MinSHMargin_C','Feasible'});
ok=result.table.CommandRate_MW_min(logical(result.table.Feasible));
if isempty(ok)
    result.highest_tested_feasible_command_rate_MW_min=NaN;
else
    result.highest_tested_feasible_command_rate_MW_min=max(ok);
end
result.note='Conditional grid result for the supplied policy, initial state and simulation horizon.';
disp(result.table);
end
