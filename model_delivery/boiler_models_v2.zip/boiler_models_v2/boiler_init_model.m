function boiler_init_model(model)
% Load property tables and non-secret parameters into each MODEL workspace.
% Existing parameter edits are retained. Real DCS inputs are never replaced.
folder = fileparts(mfilename('fullpath'));
data = load(fullfile(folder,'steam_properties.mat'),'st');
mw = get_param(model,'ModelWorkspace');
if ~mw.hasVariable('st'), mw.assignin('st',data.st); end
if ~mw.hasVariable('shp')
    if contains(model,'with_sh_spray'), kind='integrated'; else, kind='standalone'; end
    paramFile=fullfile(folder,'boiler_parameters.mat');
    if isfile(paramFile)
        x=load(paramFile,'shp');
        assert(isfield(x,'shp'),'Parameter MAT must contain shp.');
        shp=x.shp;
    else
        shp=boiler_default_parameters(data.st,kind);
    end
    mw.assignin('shp',shp);
end
end

