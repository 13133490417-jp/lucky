"""Regenerate IF97 lookup tables offline. Not a MATLAB Function block.
Run: python -m pip install -r requirements_python_validation.txt
     python rebuild_steam_tables.py
The MAT file is the only property dependency of the Simulink models.
"""
from pathlib import Path
import numpy as np
from scipy.io import savemat
from scipy.optimize import brentq
from CoolProp.CoolProp import PropsSI
OUT=Path(__file__).resolve().parent

def props(out, p, key, values):
    result=[]
    for v in values:
        try:
            result.append(PropsSI(out, 'P', float(p)*1e6, key, float(v), 'IF97::Water'))
        except ValueError as e:
            if out=='T' and key=='H':
                # Supported inversion of the IF97 forward relation for
                # states where the backend's backward routine rejects p,h.
                lower,upper=273.16,1073.15
                if p<22.064:
                    ts=PropsSI('T','P',float(p)*1e6,'Q',1,'IF97::Water')
                    hf=PropsSI('H','P',float(p)*1e6,'Q',0,'IF97::Water')
                    hg=PropsSI('H','P',float(p)*1e6,'Q',1,'IF97::Water')
                    if hf<=v<=hg:
                        result.append(ts);continue
                    if v<hf:upper=ts-.02
                    else:lower=ts+.02
                result.append(brentq(lambda T:PropsSI('H','P',float(p)*1e6,'T',T,'IF97::Water')-v,lower,upper,xtol=1e-8))
                continue
            # At an almost exact saturation PT pair, use the specified side
            # of the IF97 saturation boundary. Wet/near-saturation input is
            # separately rejected by the Simulink phase/domain monitor.
            if key!='T' or 'Saturation pressure' not in str(e) or p>=22.064:raise
            ts=PropsSI('T','P',float(p)*1e6,'Q',1,'IF97::Water')
            quality=1 if v>=ts else 0
            result.append(PropsSI(out,'P',float(p)*1e6,'Q',quality,'IF97::Water'))
    return np.array(result)

def make_tables():
    # These are offline property tables, not executable Simulink functions.
    pg = np.arange(2., 32.001, .25)
    tg = np.arange(250., 650.001, 1.)
    # IF97 backward T(p,h) covers regions 1--4 here, not arbitrary region 5.
    hg = np.arange(1800., 3950.001, 5.)
    pwg = np.arange(2., 40.001, .5)
    twg = np.arange(20., 350.001, 2.)
    hm = np.vstack([props('H', p, 'T', tg+273.15)/1000 for p in pg])
    tm = np.vstack([props('T', p, 'H', hg*1000)-273.15 for p in pg])
    hw = np.vstack([props('H', p, 'T', twg+273.15)/1000 for p in pwg])
    satp = np.r_[np.arange(2., 22.001, .025), 22.06]
    sat = np.array([PropsSI('T', 'P', float(p)*1e6, 'Q', 1, 'IF97::Water')-273.15 for p in satp])
    st = dict(p=pg, t=tg, h=hg, pw=pwg, tw=twg, hPT=hm, TPH=tm, hwPT=hw, psat=satp, Tsat=sat)
    assert all(np.isfinite(v).all() for v in st.values())
    savemat(OUT/'steam_properties.mat', {'st':st}, do_compression=True, oned_as='row')
    return st

if __name__=='__main__':
    make_tables()
    print('Saved IF97 steam_properties.mat')
