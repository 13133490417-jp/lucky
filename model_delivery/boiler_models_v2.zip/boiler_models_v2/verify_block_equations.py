"""Python verification, NOT MATLAB/Simulink compilation or simulation."""
from pathlib import Path
import sys,json,hashlib,zipfile,re
import xml.etree.ElementTree as E
import numpy as np
from scipy.io import loadmat
from scipy.interpolate import RegularGridInterpolator
from scipy.integrate import solve_ivp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from CoolProp.CoolProp import PropsSI

OUT=Path(__file__).resolve().parent
SRC=OUT/'lu_xin_rui_original.slx'
st=loadmat(OUT/'steam_properties.mat',simplify_cells=True)['st']
spec=json.loads((OUT/'block_graph.json').read_text())
def interpolate(table,*coords):
    grids={'hPT':('p','t'),'TPH':('p','h'),'hwPT':('pw','tw'),'Tsat':('psat',)}[table]
    vv=[np.clip(x,st[g][0],st[g][-1]) for x,g in zip(coords,grids)]
    return float(RegularGridInterpolator(tuple(st[g] for g in grids),st[table],bounds_error=False,fill_value=np.nan)(np.array([vv]))[0])

def defaults(integrated=False):
    p=dict(Tmid0=425.,Pmid0=20.,Pmain0=18.,Dmain0=800.,rB0=100.,W0=np.array([5.,5.,5.,5.]),Pwater0=28.,Twater0=270.,Tmain0=540.,Tmax=575.,Tmin=535.,SHmin=15.,flow_epsilon=1e-6,PT_guard=2.,tau_transport=15.,step_time=100.,mid_drop=10.,legacy_coal_scale=1.)
    if integrated:
        p.update(Tmid0=394.882263,Pmid0=21.514715,Pmain0=21.514715-.00007023*824.233337**1.5,rB0=131.327881)
    p['hmid0']=interpolate('hPT',p['Pmid0'],p['Tmid0'])
    p['hwater0']=interpolate('hwPT',p['Pwater0'],p['Twater0'])
    hp=np.array([interpolate('TPH',p['Pmain0'],h) for h in st['h']])
    ts,indices=np.unique(hp,return_index=True)
    p['hmain0']=float(np.interp(p['Tmain0'],ts,st['h'][indices]))
    ds=p['Dmain0']-sum(p['W0'])
    p['hpre0']=(p['Dmain0']*p['hmain0']-sum(p['W0'])*p['hwater0'])/ds
    p['Ch']=ds*90.
    p['k2']=ds*(p['hpre0']-p['hmid0'])/p['rB0']
    return p

def parameter(s,p):
    if s in ['Inf','NaN']:return float(s.lower())
    if s.startswith('1/'):return 1/parameter(s[2:],p)
    m=re.fullmatch(r'(shp|st)\.(\w+)(?:\((\d+|end)\))?',s)
    if m:
        obj=p if m[1]=='shp' else st
        val=obj[m[2]]
        return val[-1 if m[3]=='end' else int(m[3])-1] if m[3] else val
    return float(s)

def evaluate(g,ins,p,state,h_delayed):
    values={};incoming={};derivatives={}
    for l in g['lines']:incoming[(l['dst'],l['inp'])]=(l['src'],l['out'])
    blocks={b['name']:b for b in g['blocks']}
    pending=list(blocks)
    for name in pending[:]:
        b=blocks[name];typ=b['type']
        if typ=='Inport':values[(name,1)]=ins[int(b['params']['Port'])-1];pending.remove(name)
        elif typ=='Integrator':values[(name,1)]=state;pending.remove(name)
        elif typ=='TransportDelay':values[(name,1)]=h_delayed;pending.remove(name)
        elif typ=='Constant':values[(name,1)]=parameter(b['params']['Value'],p);pending.remove(name)
    while pending:
        old=len(pending)
        for name in pending[:]:
            b=blocks[name];args=[]
            for i in range(1,(b['inputs'] or 0)+1):
                source=incoming.get((name,i))
                if source not in values:break
                args.append(values[source])
            if len(args)!=(b['inputs'] or 0):continue
            q=b['params'];typ=b['type']
            if typ=='Sum':v=sum(a if sign=='+' else -a for a,sign in zip(args,q['Inputs']))
            elif typ=='Product':
                v=1.
                for a,op in zip(args,q['Inputs']):v=v*a if op=='*' else v/a
            elif typ=='Gain':v=args[0]*parameter(q['Gain'],p)
            elif typ=='MinMax':v=max(args)
            elif typ=='Lookup_n-D':v=interpolate(q['Table'].split('.')[1],*args)
            elif typ=='RelationalOperator':
                a,c=args;op=q['Operator'];v={'>=':lambda:a>=c,'<=':lambda:a<=c,'>':lambda:a>c,'<':lambda:a<c}[op]()
            elif typ=='Logic':v=all(args) if q['Operator']=='AND' else any(args)
            elif typ=='Switch':v=args[0] if args[1]!=0 else args[2]
            elif typ=='Outport':v=args[0]
            elif typ=='SubSystem':
                sub,d=evaluate(b['system'],args,p,state,h_delayed)
                for n,val in enumerate(sub,1):values[(name,n)]=val
                derivatives.update({name+'/'+k:v for k,v in d.items()})
                pending.remove(name);continue
            else:raise AssertionError(typ)
            values[(name,1)]=v;pending.remove(name)
        assert len(pending)<old,pending
    outs=[]
    for name,b in sorted(blocks.items(),key=lambda x:int(x[1]['params'].get('Port','0'))):
        if b['type']=='Outport':outs.append(values[(name,1)])
        if b['type']=='Integrator':derivatives[name]=values[incoming[(name,1)]]
    return outs,derivatives

core=next(b['system'] for b in spec['standalone']['blocks'] if b['type']=='SubSystem')
p=defaults()
def ins_for(T,p=p):return [T,p['Pmid0'],p['Pmain0'],p['Dmain0'],p['rB0'],*p['W0'],p['Pwater0'],p['Twater0']]
y,d=evaluate(core,ins_for(p['Tmid0']),p,p['hpre0'],p['hmid0'])
assert abs(y[0]-540)<1e-8 and abs(next(iter(d.values())))<1e-8
assert y[10] and y[11] and y[12]

checks=[]
def check(name,condition,detail=''):
    assert condition,name+': '+detail
    checks.append(dict(name=name,passed=True,detail=detail))
check('Default steady heat balance',abs(next(iter(d.values())))<1e-8)
check('Default steam/spray energy balance',abs((p['Dmain0']-20)*p['hpre0']+20*p['hwater0']-p['Dmain0']*y[1])<1e-6)
check('Default safety and domain flags',bool(y[12]))

# Numerical integration of the SAME graph's integrator derivative.
def experiment(drop):
    # Split at the delayed discontinuity to preserve event timing.
    event=p['step_time']+p['tau_transport']
    hnew=interpolate('hPT',p['Pmid0'],p['Tmid0']-drop)
    def rhs(t,x):
        hd=p['hmid0'] if t<event else hnew
        _,di=evaluate(core,ins_for(p['Tmid0'] if t<100 else p['Tmid0']-drop),p,x[0],hd)
        return [next(iter(di.values()))]
    # With fixed coefficients this has an exact solution, independently
    # checked against the numerical integration of block-graph derivatives.
    ds=p['Dmain0']-sum(p['W0']);tau=p['Ch']/ds
    hfinal=hnew+p['k2']*p['rB0']/ds
    t=np.arange(0.,601.,1.)
    exact=np.where(t<event,p['hpre0'],hfinal+(p['hpre0']-hfinal)*np.exp(-(t-event)/tau))
    sol=solve_ivp(rhs,(event,600),[p['hpre0']],t_eval=t[t>=event],rtol=2e-8,atol=1e-8,max_step=5)
    check('Graph ODE vs exact first-order solution, drop='+str(drop),sol.success and max(abs(sol.y[0]-exact[t>=event]))<1e-4)
    yy=np.array([evaluate(core,ins_for(p['Tmid0'] if ti<100 else p['Tmid0']-drop),p,hs,p['hmid0'] if ti<event else hnew)[0] for ti,hs in zip(t,exact)],dtype=float)
    check('Demo domain remains valid, drop='+str(drop),bool(np.all(yy[:,10])))
    if drop:check('Positive mid drop lowers main temperature, drop='+str(drop),yy[-1,0]<540)
    return t,yy

datasets={}
for drop in [0,2,10]:datasets[drop]=experiment(drop)
check('Large demo step is rejected by lower temperature margin',not bool(datasets[10][1][-1,12]))
check('Small demo step remains feasible',bool(datasets[2][1][-1,12]))
v=ins_for(p['Tmid0']);v[1]=23.;v[2]=21.
ys,_=evaluate(core,v,p,p['hpre0'],p['hmid0'])
check('Supercritical SH is explicitly undefined',np.isnan(ys[6]) and not ys[11] and not ys[12])
v=ins_for(p['Tmid0']);v[5]=801.
ys,_=evaluate(core,v,p,p['hpre0'],p['hmid0'])
check('Spray greater than steam rejects domain',not ys[10] and not ys[12])
v=ins_for(p['Tmid0']);v[0]=660.
ys,_=evaluate(core,v,p,p['hpre0'],p['hmid0'])
check('Clipped table value is flagged outside domain',not ys[10])
v=ins_for(p['Tmid0']);v[5]=float('inf')
ys,_=evaluate(core,v,p,p['hpre0'],p['hmid0'])
check('Infinite flow is rejected',not ys[10])

# Random single-phase interpolation checks, away from the saturation boundary.
rng=np.random.default_rng(20261012);herr=[];terr=[];hwerr=[]
for _ in range(300):
    pm=rng.uniform(5,21.5);ts=PropsSI('T','P',pm*1e6,'Q',1,'IF97::Water')-273.15
    T=rng.uniform(ts+12,580)
    h=PropsSI('H','P',pm*1e6,'T',T+273.15,'IF97::Water')/1000
    herr.append(abs(interpolate('hPT',pm,T)-h))
    terr.append(abs(interpolate('TPH',pm,h)-T))
    pw=rng.uniform(23,36);tw=rng.uniform(180,300)
    href=PropsSI('H','P',pw*1e6,'T',tw+273.15,'IF97::Water')/1000
    hwerr.append(abs(interpolate('hwPT',pw,tw)-href))
check('Sampled inlet h interpolation < 2 kJ/kg',max(herr)<2)
check('Sampled inverse T interpolation < 0.4 C',max(terr)<.4)
check('Sampled liquid h interpolation < 0.2 kJ/kg',max(hwerr)<.2)

def unpack(path):
    with zipfile.ZipFile(path) as z:
        check(path.name+' ZIP CRC',z.testzip() is None)
        parts={n:z.read(n) for n in z.namelist()}
    for n,b in parts.items():
        if n.endswith('.xml') or n.endswith('.rels'):E.fromstring(b)
    check(path.name+' XML parse',True)
    ctdata=parts['[Content_Types].xml']
    assert b'<Types xmlns=' in ctdata and b'ns0:' not in ctdata
    ctns='http://schemas.openxmlformats.org/package/2006/content-types'
    ctr=E.fromstring(ctdata)
    overrides={q.get('PartName'):q.get('ContentType') for q in ctr.findall('{'+ctns+'}Override')}
    defaults={q.get('Extension'):q.get('ContentType') for q in ctr.findall('{'+ctns+'}Default')}
    reltype='application/vnd.openxmlformats-package.relationships+xml'
    assert overrides['/_rels/.rels']==reltype
    for part,data in parts.items():
        if part=='[Content_Types].xml':continue
        extension=part.rsplit('.',1)[-1]
        assert overrides.get('/'+part,defaults.get(extension)),part
        if part.endswith('.rels'):
            assert b'<Relationships xmlns=' in data and b'ns0:' not in data
            assert overrides['/'+part]==reltype
    check(path.name+' conventional OPC namespaces and every part content type',True)
    for n,b in parts.items():
        if not n.endswith('.rels'):continue
        rr=E.fromstring(b)
        base=Path(n).parent.parent
        for rel in rr:
            target=rel.get('Target')
            if rel.get('TargetMode')=='External':continue
            assert str(base/target) in parts,(n,target)
    check(path.name+' all package relationship targets exist',True)
    ids={};lines=[];root=None
    for n,b in parts.items():
        if n.startswith('simulink/systems/') and n.endswith('.xml') and '/_rels/' not in n:
            s=E.fromstring(b)
            if n.endswith('system_root.xml'):root=s
            for bb in s.findall('Block'):
                sid=bb.get('SID');check(path.name+' unique SID '+sid,sid not in ids);ids[sid]=bb
            lines+=s.findall('Line')
    dests=set()
    for l in lines:
        src=l.find("P[@Name='Src']").text
        assert src.split('#')[0] in ids
        for d in l.iter('P'):
            if d.get('Name')=='Dst':
                assert d.text.split('#')[0] in ids
                assert d.text not in dests,d.text
                dests.add(d.text)
    check(path.name+' line endpoint IDs and unique destinations',True)
    rootports=sorted(int(bb.find("P[@Name='Port']").text) if bb.find("P[@Name='Port']") is not None else 1 for bb in root.findall('Block') if bb.get('BlockType')=='Outport')
    check(path.name+' continuous output port numbering',rootports==list(range(1,len(rootports)+1)))
    return root,ids,parts

r1,ids1,parts1=unpack(OUT/'sh_spray_standalone.slx')
r2,ids2,parts2=unpack(OUT/'lu_xin_rui_with_sh_spray.slx')
with zipfile.ZipFile(SRC) as z:orig=E.fromstring(z.read('simulink/systems/system_root.xml'))
for b in orig.findall('Block'):
    # Whole block contents and all original parameters remain identical.
    other=ids2[b.get('SID')]
    def canonical(x):return (x.tag,tuple(sorted(x.attrib.items())),(x.text or '').strip(),tuple(canonical(v) for v in x))
    assert canonical(b)==canonical(other),b.get('Name')
check('All original blocks/parameters retained',True)
def edges(root):
    result=set()
    for l in root.findall('Line'):
        src=l.find("P[@Name='Src']").text
        result|={(src,p.text) for p in l.iter('P') if p.get('Name')=='Dst'}
    return result
check('All original source/destination connections retained',edges(orig)<=edges(r2))
check('Original backup SHA256 unchanged',hashlib.sha256(SRC.read_bytes()).hexdigest()=='fa820ee4c9d4c52a9fc0453b55ee50204cde43c525bb50c60e2f2c08d13617de')
check('New graph contains no MATLAB Function/Fcn/S-Function',all(b.get('BlockType') not in ['Fcn','S-Function','MATLABFunction'] for sid,b in ids2.items() if int(sid)>200))

# Reference simulation of the untouched legacy differential equations, then
# the attached new module. This is NOT a Simulink engine validation.
pi=defaults(True);ut=10.273707*131.327881/(.745734*21.514715)
def old_rhs(t,x):
    m,rb,q,tc,pd,ne=x
    qin=.001022*8.061679*(tc-9.1552513610*(pd-15.857052)-150.3078719)*q
    dout=.745734*pd*ut
    return [(131.327881-m)/114.592485,(m-rb)/22.647481,(824.233337-q)/62.539345,(10.273707*rb-qin)/1934.514119,(qin-dout)/327.536077,((1-.810875)*dout-ne)/5.000043]
old=solve_ivp(old_rhs,(0,600),[131.327881,131.327881,824.233337,394.882263,21.514715,262.247742],rtol=1e-8,atol=1e-9,max_step=1,dense_output=True)
check('Original-equation reference integration completes',old.success)
def original_inputs(t):
    x=old.sol(max(0,t));td=394.882263 if t<88.039457 else old.sol(t-88.039457)[3]
    pm=x[4];ps=pm-.00007023*x[2]**1.5
    return [td,pm,ps,800,x[1],5,5,5,5,28,270]
def attached_rhs(t,x):
    mid=original_inputs(max(0,t-15))
    hm=pi['hmid0'] if t<15 else interpolate('hPT',mid[1],mid[0])
    _,dd=evaluate(core,original_inputs(t),pi,x[0],hm)
    return [next(iter(dd.values()))]
attached=solve_ivp(attached_rhs,(0,600),[pi['hpre0']],rtol=2e-8,atol=1e-8,max_step=5)
check('Attached-equation reference integration completes',attached.success and np.isfinite(attached.y).all())
yi=[evaluate(core,original_inputs(t),pi,h,pi['hmid0'] if t<15 else interpolate('hPT',original_inputs(t-15)[1],original_inputs(t-15)[0]))[0] for t,h in zip(attached.t,attached.y[0])]
yi=np.asarray(yi,dtype=float)
check('Attached demo produces finite main temperature',np.isfinite(yi[:,0]).all())

fig,ax=plt.subplots(2,1,figsize=(9,6),sharex=True,layout='constrained')
for drop,(t,y) in datasets.items():
    ax[0].plot(t,np.where(t<100,425,425-drop),label=f'Mid drop {drop} C')
    ax[1].plot(t,y[:,0],label=f'Mid drop {drop} C')
ax[0].set_ylabel('Mid temperature [C]');ax[1].set_ylabel('Main temperature [C]');ax[1].set_xlabel('Time [s]')
ax[1].axhline(535,color='r',linestyle='--',label='DEMO lower limit')
for a in ax:a.grid(alpha=.25);a.legend(loc='best')
fig.suptitle('DEMONSTRATION PARAMETERS - Python block-equation validation\nNot a MATLAB/Simulink run and not a plant limit')
fig.savefig(OUT/'demo_response.png',dpi=150);plt.close(fig)
numeric={'demo_Ch_kg':p['Ch'],'demo_k2_kJkg':p['k2'],'demo_2C_main_drop_at_600s_C':float(540-datasets[2][1][-1,0]),'demo_10C_main_drop_at_600s_C':float(540-datasets[10][1][-1,0]),'sampled_hPT_max_abs_error_kJkg':max(herr),'sampled_TPH_max_abs_error_C':max(terr),'sampled_hwPT_max_abs_error_kJkg':max(hwerr),'integrated_demo_final_main_C':float(yi[-1,0]),'integrated_demo_min_SH_margin_C':float(np.nanmin(yi[:,9]))}
summary={'MATLAB_Simulink_execution':'NOT AVAILABLE; SLX compile/load NOT tested','checks':checks,'numeric_demonstration_only':numeric,'original_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest()}
(OUT/'validation_report.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(numeric,indent=2));print('Passed checks:',len(checks))
