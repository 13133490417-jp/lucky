function start_here()
% Generate and open the block diagrams using MATLAB's own Simulink APIs.
% No MATLAB Function blocks are created. See README for calibration limits.
folder=fileparts(mfilename('fullpath'));
addpath(folder);
build_boiler_models();
open_system('sh_spray_standalone_rebuilt');
open_system('lu_xin_rui_with_sh_spray_rebuilt');
fprintf('Opened the two models saved by MATLAB/Simulink.\n');
end
