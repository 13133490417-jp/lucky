function build_boiler_models()
% Official Simulink API reconstruction of the two delivered block diagrams.
% Run in MATLAB R2023b+ with Simulink. No MATLAB Function/Fcn/S-Function
% blocks are added. Files ending _rebuilt are written; delivered SLX and
% the user's original source file are never overwritten.
folder=fileparts(mfilename('fullpath'));
addpath(folder);
spec=jsondecode(fileread(fullfile(folder,'block_graph.json')));
stand='sh_spray_standalone_rebuilt';
integ='lu_xin_rui_with_sh_spray_rebuilt';
assert(~isfile(fullfile(folder,[stand '.slx'])) && ...
       ~isfile(fullfile(folder,[integ '.slx'])), ...
       'Rebuilt files already exist. Rename them before rebuilding.');
new_system(stand);
set_param(stand,'Solver','ode15s','StopTime','600','MaxStep','1', ...
    'RelTol','1e-6','SaveOutput','on','SaveTime','on', ...
    'SaveFormat','Dataset','OutputSaveName','yout','TimeSaveName','tout', ...
    'ReturnWorkspaceOutputs','on');
add_graph(stand,spec.standalone);
install_callbacks(stand);
boiler_init_model(stand);
save_system(stand,fullfile(folder,[stand '.slx']));
load_system(fullfile(folder,'lu_xin_rui_original.slx'));
save_system('lu_xin_rui_original',fullfile(folder,[integ '.slx']));
% save_system with a new filename changes the loaded model's name.
add_graph(integ,spec.integrated_additions);
for j=1:numel(spec.external)
    x=spec.external(j);
    add_line(integ,sprintf('%s/%d',x.src,x.out), ...
        sprintf('%s/%d',x.dst,x.inp),'autorouting','on');
end
set_param(integ,'StopTime','600','MaxStep','1','RelTol','1e-6');
install_callbacks(integ);
boiler_init_model(integ);
save_system(integ);
fprintf('Created %s and %s using Simulink add_block/add_line.\n',stand,integ);
end

function install_callbacks(model)
cb="eval(fileread(fullfile(fileparts(get_param(bdroot,'FileName')),'model_load_callback.m')));";
set_param(model,'PostLoadFcn',char(cb),'InitFcn',char(cb));
end

function add_graph(parent,g)
for j=1:numel(g.blocks)
    b=g.blocks(j);
    path=[parent '/' b.name];
    add_block(library_block(b.type),path,'Position',reshape(b.pos,1,[]));
    keys=fieldnames(b.params);
    for k=1:numel(keys), set_param(path,keys{k},b.params.(keys{k})); end
    if strcmp(b.type,'SubSystem')
        % A library Subsystem contains default In1/Out1 and a line.
        lh=find_system(path,'FindAll','on','SearchDepth',1,'Type','line');
        for n=1:numel(lh), delete_line(lh(n)); end
        bh=find_system(path,'SearchDepth',1,'Type','Block');
        for n=2:numel(bh), delete_block(bh{n}); end
        add_graph(path,b.system);
    end
end
for j=1:numel(g.lines)
    x=g.lines(j);
    add_line(parent,sprintf('%s/%d',x.src,x.out), ...
        sprintf('%s/%d',x.dst,x.inp),'autorouting','on');
end
end

function s=library_block(t)
switch t
    case 'Inport', s='simulink/Ports & Subsystems/In1';
    case 'Outport', s='simulink/Ports & Subsystems/Out1';
    case 'SubSystem', s='simulink/Ports & Subsystems/Subsystem';
    case 'Constant', s='simulink/Sources/Constant';
    case 'Step', s='simulink/Sources/Step';
    case 'FromWorkspace', s='simulink/Sources/From Workspace';
    case 'Gain', s='simulink/Math Operations/Gain';
    case 'Sum', s='simulink/Math Operations/Sum';
    case 'Product', s='simulink/Math Operations/Product';
    case 'MinMax', s='simulink/Math Operations/MinMax';
    case 'Integrator', s='simulink/Continuous/Integrator';
    case 'TransportDelay', s='simulink/Continuous/Transport Delay';
    case 'Lookup_n-D', s='simulink/Lookup Tables/n-D Lookup Table';
    case 'Logic', s='simulink/Logic and Bit Operations/Logical Operator';
    case 'RelationalOperator', s='simulink/Logic and Bit Operations/Relational Operator';
    case 'Switch', s='simulink/Signal Routing/Switch';
    otherwise, error('Unapproved block type: %s',t);
end
end

