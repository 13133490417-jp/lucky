function result=scan_temperature_drop(drops, allowDemo, model)
% Fixed-pressure/fixed-flow/fixed-fuel/fixed-spray disturbance scan.
% The highest feasible grid point is NOT an all-control-strategy optimum.
% Use calibrated shp in Model Workspace for quantitative research results.
if nargin<1, drops=0:0.5:30; end
if nargin<2, allowDemo=false; end
if nargin<3, model='sh_spray_standalone'; end
folder=fileparts(mfilename('fullpath'));addpath(folder);
load_system(fullfile(folder,[model '.slx']));boiler_init_model(model);
mw=get_param(model,'ModelWorkspace');shp=mw.getVariable('shp');
assert(allowDemo || (shp.calibrated && shp.units_confirmed), ...
    'Confirm units and identify parameters before estimating a plant limit.');
assert(all(isfinite(drops)) && all(drops>=0),'Drops must be finite and nonnegative.');
rows=zeros(numel(drops),7);
for j=1:numel(drops)
    p=shp;p.mid_drop=drops(j);
    si=Simulink.SimulationInput(model);
    si=si.setVariable('shp',p,'Workspace',model);
    si=si.setModelParameter('StopTime',num2str(p.stop_time),'MaxStep','1');
    out=sim(si);y=out.yout;
    tm=y.getElement('T_main_C').Values;
    up=y.getElement('Margin_Tmax_C').Values;
    lo=y.getElement('Margin_Tmin_C').Values;
    sh=y.getElement('Margin_SH_C').Values;
    domain=y.getElement('PropertyDomainOK').Values;
    defined=y.getElement('SHcriterionOK').Values;
    feasible=all(isfinite(tm.Data)) && all(domain.Data) && all(defined.Data) && ...
        all(up.Data>=0) && all(lo.Data>=0) && all(sh.Data>=0);
    rows(j,:)=[drops(j),shp.Tmain0-tm.Data(end),min(up.Data),min(lo.Data), ...
        min(sh.Data),all(domain.Data),feasible];
end
result.table=array2table(rows,'VariableNames',{'MidDrop_C','FinalMainDrop_C', ...
    'MinUpperMargin_C','MinLowerMargin_C','MinSHMargin_C','PropertyDomainOK','Feasible'});
ok=result.table.MidDrop_C(logical(result.table.Feasible));
if isempty(ok)
    result.highest_tested_feasible_drop_C=NaN;
else
    result.highest_tested_feasible_drop_C=max(ok);
end
result.demonstration=~(shp.calibrated && shp.units_confirmed);
result.assumptions='Fixed D_main, rB, pressures and all spray flows. Finite-horizon grid scan.';
disp(result.table);
end

