% Model callback: initialise only missing model-workspace data.
% This script creates no Simulink MATLAB Function blocks.
addpath(fileparts(get_param(bdroot,'FileName')));
boiler_init_model(bdroot);

