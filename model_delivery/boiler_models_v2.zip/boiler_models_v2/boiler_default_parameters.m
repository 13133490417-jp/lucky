function shp = boiler_default_parameters(st, kind)
% DEMONSTRATION ONLY. Replace using an identified operating point.
% All NEW MODULE flows are kg/s, pressures MPa, temperatures degC,
% enthalpies kJ/kg and time seconds. Legacy input units are NOT inferred.
if nargin < 2, kind = 'standalone'; end
shp.calibrated = false;
shp.units_confirmed = false;
shp.kind = kind;
shp.legacy_flow_scale = 1; % 1 if old model is kg/s; 1/3.6 if t/h.
shp.legacy_coal_scale = 1;
shp.Tmid0 = 425;
shp.Pmid0 = 20;
shp.Pmain0 = 18;
shp.Dmain0 = 800;
shp.rB0 = 100;
shp.UB0 = 131.327881;
shp.UW0 = 824.233337;
shp.UT0 = 80; % Demo only: original data Ut/UT was not uploaded.
if strcmp(kind,'integrated')
    % Read from the uploaded legacy model's fixed initial conditions.
    % Do not alter them: they are not a verified equilibrium.
    shp.Tmid0 = 394.882263;
    shp.Pmid0 = 21.514715;
    shp.Pmain0 = shp.Pmid0-0.00007023*shp.UW0^1.5;
    shp.Dmain0 = 800; % Independent demo mass flow, NOT inferred from Lu's K3.
    shp.rB0 = 131.327881*shp.legacy_coal_scale;
    % Demo command chosen from the OLD fitted pressure equation's equilibrium.
    % The uploaded state's temperature/power initial conditions are retained.
    shp.UT0 = 10.273707*131.327881/(0.745734*shp.Pmid0);
end
shp.Tmain0 = 540;
shp.W0 = [5 5 5 5];
shp.Pwater0 = 28;
shp.Twater0 = 270;
shp.Tmax = 575; % EXAMPLE: not the unit's approved safety limit.
shp.Tmin = 535; % EXAMPLE: required for a meaningful temperature-drop bound.
shp.SHmin = 15; % EXAMPLE: replace with operating specification.
shp.flow_epsilon = 1e-6;
shp.PT_guard = 2; % Table interpolation guard only, not SHmin.
shp.tau_transport = 15; % Additional downstream transport, NOT Lu's 88 s.
shp.step_time = 100;
shp.mid_drop = 10;
shp.stop_time = 600;
shp.Dsteam0 = shp.Dmain0-sum(shp.W0);
assert(shp.Dsteam0>0,'Spray flow must be smaller than main steam flow.');
shp.hmid0 = interp2(st.t,st.p,st.hPT,shp.Tmid0,shp.Pmid0,'linear');
shp.hwater0 = interp2(st.tw,st.pw,st.hwPT,shp.Twater0,shp.Pwater0,'linear');
% Obtain h_main at the chosen T by inverting the SAME table used by the blocks.
hp = interp1(st.p,st.TPH,shp.Pmain0,'linear');
[tp,ind] = unique(hp,'stable');
shp.hmain0 = interp1(tp,st.h(ind),shp.Tmain0,'linear');
shp.hpre0 = (shp.Dmain0*shp.hmain0-sum(shp.W0)*shp.hwater0)/shp.Dsteam0;
shp.Q0 = shp.Dsteam0*(shp.hpre0-shp.hmid0);
shp.k2 = shp.Q0/shp.rB0; % kJ/kg fuel, equivalent absorbed-heat coefficient.
shp.Ch = shp.Dsteam0*90; % kg equivalent storage; gives demo tau=90 s.
assert(all(isfinite([shp.hmid0 shp.hmain0 shp.hpre0 shp.k2 shp.Ch])));
assert(shp.k2>0 && shp.Ch>0);
end

