function results = run_demo(useRebuilt)
% MATLAB smoke test of BOTH models. SimulationInput variables are demo data
% scoped to each simulation; existing base-workspace data is not overwritten.
% All computed limits are demonstrations and must NOT be used for operation.
if nargin<1, useRebuilt=false; end
folder=fileparts(mfilename('fullpath')); addpath(folder);
names={'sh_spray_standalone','lu_xin_rui_with_sh_spray'};
if useRebuilt, names=cellfun(@(x)[x '_rebuilt'],names,'UniformOutput',false); end
results=struct;
for j=1:2
    model=names{j};load_system(fullfile(folder,[model '.slx']));
    boiler_init_model(model);
    mw=get_param(model,'ModelWorkspace');
    if j==1, kind='standalone'; else, kind='integrated'; end
    shp=boiler_default_parameters(mw.getVariable('st'),kind);
    in=Simulink.SimulationInput(model);
    in=in.setVariable('shp',shp,'Workspace',model);
    in=in.setModelParameter('StopTime','600','MaxStep','1','RelTol','1e-6');
    if j==2
        values={shp.UB0,shp.UW0,shp.UT0,shp.Tmid0,shp.Pmain0,262.247742, ...
            shp.W0(1),shp.W0(2),shp.W0(3),shp.W0(4),shp.Pwater0,shp.Twater0,shp.Dmain0};
        vars={'UB','UW','UT','T','Pt','Ne','W1L','W1R','W2L','W2R','Pwater','Twater','Dmain'};
        for k=1:numel(vars)
            in=in.setVariable(vars{k},timeseries([values{k};values{k}],[0;600]));
        end
    end
    out=sim(in);
    y=out.yout;
    t=y.getElement('T_main_C').Values;
    assert(all(isfinite(t.Data)),'Main temperature contains invalid values.');
    if j==1
        base=t.Data(t.Time<shp.step_time);
        assert(max(abs(base-shp.Tmain0))<0.03,'Incorrect steady initialisation.');
        beforeTransport=t.Data(t.Time<shp.step_time+shp.tau_transport-0.01);
        assert(max(abs(beforeTransport-shp.Tmain0))<0.03,'Incorrect transport timing.');
        assert(t.Data(end)<shp.Tmain0-0.1,'Mid temperature drop did not lower main temperature.');
        dv=y.getElement('PropertyDomainOK').Values;
        assert(all(dv.Data),'Demo left property validity domain.');
    end
    added=find_system([model '/SH_Spray_Extension'], ...
        'LookUnderMasks','all','FollowLinks','on','Type','Block');
    allowed={'SubSystem','Inport','Outport','Constant','Sum','Product','Gain', ...
        'Integrator','TransportDelay','Lookup_n-D','MinMax','RelationalOperator','Logic','Switch'};
    for k=1:numel(added)
        assert(ismember(get_param(added{k},'BlockType'),allowed), ...
            ['Unexpected block in extension: ' added{k}]);
    end
    results.(model)=out;
    fprintf('%s: simulation executed; final T_main = %.3f C (DEMO).\n',model,t.Data(end));
end
save(fullfile(folder,'matlab_demo_results.mat'),'results');
fprintf('No plant readiness claim: parameters, units and safety limits need confirmation.\n');
end

