function sig=read_dcs_signals(filename,cfg)
% Read real DCS CSV without inventing time, units or control-command meaning.
% Required cfg: TimeColumn, TimeScale (numeric time -> seconds),
% ModuleFlowScale (DCS flow -> kg/s), PressureScale (DCS pressure -> MPa).
% Optional cfg.LegacyColumns and cfg.LegacyScales must both contain UB/UW/UT
% when preparing the legacy model's commands in its ORIGINAL fitted units.
required={'TimeColumn','TimeScale','ModuleFlowScale','PressureScale'};
for j=1:numel(required), assert(isfield(cfg,required{j}),['Missing cfg.' required{j}]); end
assert(all(isfinite([cfg.TimeScale cfg.ModuleFlowScale cfg.PressureScale])) && ...
    all([cfg.TimeScale cfg.ModuleFlowScale cfg.PressureScale]>0));
tab=readtable(filename,'VariableNamingRule','preserve');
assert(ismember(cfg.TimeColumn,tab.Properties.VariableNames),'Time column missing.');
t=tab.(cfg.TimeColumn);
if isdatetime(t)
    t=seconds(t-t(1));
elseif isnumeric(t)
    t=(t-t(1))*cfg.TimeScale;
else
    error('Time must be a numeric or datetime column.');
end
t=t(:);assert(numel(t)>=3 && all(isfinite(t)) && all(diff(t)>0), ...
    'Timestamps must be finite, increasing and free of duplicate rows.');
maps={ ...
    'Dmain','主蒸汽流量',cfg.ModuleFlowScale; ...
    'W1L','一级左减温水流量',cfg.ModuleFlowScale; ...
    'W1R','一级右减温水流量',cfg.ModuleFlowScale; ...
    'W2L','二级左减温水流量',cfg.ModuleFlowScale; ...
    'W2R','二级右减温水流量',cfg.ModuleFlowScale; ...
    'Pwater','锅炉给水调阀前压力',cfg.PressureScale; ...
    'Twater','锅炉给水调阀前温度',1; ...
    'T','分离器出口温度',1; ...
    'Pmid_measured','分离器出口蒸汽压力',cfg.PressureScale; ...
    'Pt','末过出口压力',cfg.PressureScale; ...
    'Ne','发电机功率',1; ...
    'Tmain_measured','末级过热器出口主蒸汽温度',1};
sig=struct;
for j=1:size(maps,1)
    tag=maps{j,2};assert(ismember(tag,tab.Properties.VariableNames),['Missing DCS column: ' tag]);
    v=tab.(tag);assert(isnumeric(v) && numel(v)==numel(t) && all(isfinite(v)), ...
        ['Invalid numeric DCS data: ' tag]);
    sig.(maps{j,1})=timeseries(v(:)*maps{j,3},t);
end
if isfield(cfg,'LegacyColumns')
    assert(isfield(cfg,'LegacyScales'),'Legacy command units need explicit scales.');
    for key={'UB','UW','UT'}
        k=key{1};assert(isfield(cfg.LegacyColumns,k) && isfield(cfg.LegacyScales,k));
        tag=cfg.LegacyColumns.(k);scale=cfg.LegacyScales.(k);
        assert(ismember(tag,tab.Properties.VariableNames) && isfinite(scale) && scale>0);
        v=tab.(tag);assert(isnumeric(v) && all(isfinite(v)));
        sig.(k)=timeseries(v(:)*scale,t);
    end
end
end
